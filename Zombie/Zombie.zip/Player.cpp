#include "stdafx.h"
#include "Player.h"
#include "Bullet.h"
#include "TileMap.h"
#include "SceneGame.h"
#include "DebugBox.h"
#include "Zombie.h"
#include "Item.h"

Player::Player(const std::string& texId, const std::string& name_in)
	: GameObject(name_in)
{
	textureId = texId;
}

void Player::SetPosition(const sf::Vector2f& pos)
{
	position = pos;
	body.setPosition(position);
}

void Player::SetRotation(float angle)
{
	rotation = angle;
	body.setRotation(rotation);
}

void Player::SetScale(const sf::Vector2f& s)
{
	scale = s;
	body.setScale(s);
}

void Player::SetOrigin(Origins preset)
{
	originPreset = preset;
	if (originPreset != Origins::Custom)
	{
		origin = Utils::SetOrigin(body, originPreset);
	}
}

void Player::SetOrigin(const sf::Vector2f& newOrigin)
{
	originPreset = Origins::Custom;
	body.setOrigin(newOrigin);
}

sf::FloatRect Player::GetLocalBounds()
{
	return body.getLocalBounds();
}

sf::FloatRect Player::GetGlobalBounds()
{
	return body.getGlobalBounds();
}

void Player::Init()
{
	sortingLayer = SortingLayers::Foreground;
	sortingOrder = 0;
	SetOrigin(Origins::MC);
}

void Player::Release()
{
}

void Player::Reset()
{
	playerMaxHp = 100;
	playerHp = 100;
	bulletCnt = 30;
	sceneGame = dynamic_cast<SceneGame*>(SCENE_MGR.GetCurrentScene());
	body.setTexture(TEXTURE_MGR.Get(textureId));
	SetOrigin(originPreset);
	tileMap = dynamic_cast<SceneGame*>(SCENE_MGR.GetCurrentScene())->GetTileMap();
	SetPosition(
		{ (tileMap->GetGlobalBounds().width + tileMap->GetGlobalBounds().left * 2) / 2,
		(tileMap->GetGlobalBounds().height + tileMap->GetGlobalBounds().top * 2) / 2
		}
	);
	movableBounds = tileMap->GetGlobalBounds();
	SetRotation(Pi / 2);
	direction = { 0.f,0.f };		
}

void Player::Update(float dt)
{		
	direction.x = InputMgr::GetAxis(Axis::Horizontal);
	direction.y = InputMgr::GetAxis(Axis::Vertical);
	float dirMagnitude = Utils::Magnitude(direction);

	if (dirMagnitude > 1.f)
	{
		Utils::Normailize(direction);
	}

	sf::Vector2i mPos = InputMgr::GetMousePosition();
	sf::Vector2f mouseWorldPos = (sf::Vector2f)mPos;

	if (sceneGame != nullptr)
	{
		mouseWorldPos = sceneGame->ScreenToWorld(mPos);
	}
	look = Utils::GetNormal(mouseWorldPos - position);

	if (GetPosition().x < movableBounds.left)
	{
		SetPosition({ movableBounds.left,GetPosition().y });
	}
	if (GetPosition().x > movableBounds.left + movableBounds.width)
	{
		SetPosition({ movableBounds.left + movableBounds.width,GetPosition().y });
	}
	if (GetPosition().y < movableBounds.top)
	{
		SetPosition({ GetPosition().x, movableBounds.top});
	}
	if (GetPosition().y > movableBounds.top + movableBounds.height)
	{
		SetPosition({ GetPosition().x, movableBounds.top + movableBounds.height});
	}
	SetRotation(Utils::Angle(look));
	SetPosition(position + direction * speed * dt);

	Utils::Clamp(bulletCnt, 0, 50);
	shootTimer += dt;

	if (shootTimer > shootDelay && InputMgr::GetMouseButtonDown(sf::Mouse::Left))
	{
		shootTimer = 0.f;
		Shoot();
	}

	if (debugBox.IsVisible())
	{
		debugBox.SetBounds(this->GetGlobalBounds());
	}
	
	auto& zlist = sceneGame->GetZombieList();
	for (auto& zombie : zlist)
	{
		if (zombie->GetGlobalBounds().intersects(this->GetGlobalBounds()))
		{
			int temp = zombie->Attack();
			playerHp -= temp;
			playerHp = Utils::Clamp(playerHp, 0, playerMaxHp);			
			if (temp)
				debugHitTimer = 0.15f;
		}

		if (playerHp <= 0)
			SCENE_MGR.ChangeScene(SceneIds::Game);
	}

	auto& iList = sceneGame->GetItemList();
	for (auto& item : iList)
	{
		if (item->GetGlobalBounds().intersects(this->GetGlobalBounds()))
		{
			sf::Vector2i temp = item->PickedUp();
			bulletCnt += temp.x;
			playerHp += temp.y;
			debugItemTimer = 0.25f;
			playerHp = Utils::Clamp(playerHp, 0, playerMaxHp);
			dynamic_cast<SceneGame*>(SCENE_MGR.GetCurrentScene())->OnItemPickedUp(item);
			break;
		}

		if (playerHp <= 0)
			SCENE_MGR.ChangeScene(SceneIds::Game);
	}

	if (debugHitTimer >= 0)
	{
		debugHitTimer -= dt;
		debugItemTimer -= dt;
		debugBox.SetDebugBoxColor(sf::Color::Red);
	}
	else if (debugItemTimer >= 0)
	{
		debugItemTimer -= dt;
		debugBox.SetDebugBoxColor(sf::Color::Blue);
	}
	else
		debugBox.SetDebugBoxColor(sf::Color::Green);
	
}

void Player::Draw(sf::RenderWindow& window)
{
	window.draw(body);
	if (debugBox.IsVisible())
		debugBox.Draw(window);
}

void Player::SetPlayerHp(int Hp_in)
{
	playerHp = Hp_in;
}

void Player::ReducePlayerHp(int dmg_in)
{
	playerHp -= dmg_in;
}

int Player::GetPlayerMaxHp()
{
	return playerMaxHp;
}

int Player::GetPlayerHp()
{
	return playerHp;
}

void Player::TurnDebugBox(bool active, sf::Color color)
{	
	debugBox.SetVisible(active);
	if (active)
	{
		debugBox.SetBounds(this->GetGlobalBounds());
		debugBox.SetDebugBoxColor(color);
	}
}

void Player::Shoot()
{
	Bullet* bullet = sceneGame->TakeBullet();
	bullet->Fire(position, look, bulletSpeed, 10);
}