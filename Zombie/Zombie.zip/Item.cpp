#include "stdafx.h"
#include "Item.h"

Item::Item(const std::string& name)
	: GameObject(name)
{
}

void Item::SetPosition(const sf::Vector2f& pos)
{
	position = pos;
	body.setPosition(position);
}

void Item::SetRotation(float angle)
{
	rotation = angle;
	body.setRotation(rotation);
}

void Item::SetScale(const sf::Vector2f& s)
{
	scale = s;
	body.setScale(scale);
}

void Item::SetOrigin(Origins preset)
{
	originPreset = preset;
	if (originPreset != Origins::Custom)
	{
		origin = Utils::SetOrigin(body, originPreset);
	}
}

void Item::SetOrigin(const sf::Vector2f& newOrigin)
{
	originPreset = Origins::Custom;
	origin = newOrigin;
	body.setOrigin(origin);
}

sf::FloatRect Item::GetLocalBounds()
{
	return body.getLocalBounds();
}

sf::FloatRect Item::GetGlobalBounds()
{
	return body.getGlobalBounds();
}

void Item::Init()
{
	sortingLayer = SortingLayers::Foreground;
	sortingOrder = 0;
	SetType(iTypes);
}

void Item::Release()
{
}

void Item::Reset()
{
	body.setTexture(TEXTURE_MGR.Get(textureId));
	SetOrigin(Origins::MC);
	SetPosition({ 0.f,0.f });
	SetRotation(0.f);
	SetScale({ 1.f,1.f });
}

void Item::Update(float dt)
{
}

void Item::Draw(sf::RenderWindow& window)
{
	window.draw(body);
}

void Item::SetType(ItemTypes type)
{
	this->iTypes = type;
	switch (this->iTypes)
	{
	case ItemTypes::Ammo:
		textureId = "graphics/ammo_pickup.png";
		addAmmo = 20;
		addHp = 0;
		break;
	case ItemTypes::Health:
		textureId = "graphics/health_pickup.png";
		addAmmo = 0;
		addHp = 20;
		break;
	}
	body.setTexture(TEXTURE_MGR.Get(textureId), true);
}

sf::Vector2i Item::PickedUp()
{
	return sf::Vector2i(addAmmo, addHp);
}
