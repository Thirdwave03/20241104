#pragma once

class Player;
class SceneGame;

class Zombie : public GameObject
{
public:
	enum class Types
	{
		Bloater,
		Chaser,
		Crawler,
	};

	static const int TotalTypes = 3;

protected:
	Types types = Types::Bloater;
	sf::Sprite body;
	std::string textureId;
	DebugBox debugBox;

	float debugHitTimer = 0;

	sf::Vector2f direction;
	
	int maxHp = 0;
	int hp = 0;

	float speed = 0.f;

	int damage = 0;

	float attackInterval = 0.f;
	float attackTimer = 0.f;

	float actionRecoveryTime = 0.f;
	float actionRecoveryTimer = 0.f;

	Player* player = nullptr;
	SceneGame* sceneGame = nullptr;

public:
	Zombie(const std::string& name = "");
	~Zombie() = default;

	void SetPosition(const sf::Vector2f& pos) override;
	void SetRotation(float angle) override;
	void SetScale(const sf::Vector2f& scale) override;

	void SetOrigin(Origins preset) override;
	void SetOrigin(const sf::Vector2f& newOrigin) override;

	sf::FloatRect GetLocalBounds() override;
	sf::FloatRect GetGlobalBounds() override;

	void Init() override;
	void Release() override;
	void Reset() override;
	void Update(float dt) override;
	void Draw(sf::RenderWindow& window) override;

	void SetType(Types type);

	int Attack();

	void TurnDebugBox(bool active, sf::Color color = sf::Color::Green) override;

	int GetZombieHp();

	void OnDamage(int dmg_in);
};
