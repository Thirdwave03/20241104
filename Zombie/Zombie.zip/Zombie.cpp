#include "stdafx.h"
#include "Zombie.h"
#include "Player.h"
#include "SceneGame.h"
#include "DebugBox.h"

Zombie::Zombie(const std::string& name)
	: GameObject(name)
{
}

void Zombie::SetPosition(const sf::Vector2f& pos)
{
	position = pos;
	body.setPosition(position);
}

void Zombie::SetRotation(float angle)
{
	rotation = angle;
	body.setRotation(rotation);
}

void Zombie::SetScale(const sf::Vector2f& s)
{
	scale = s;
	body.setScale(scale);
}

void Zombie::SetOrigin(Origins preset)
{
	originPreset = preset;
	if (originPreset != Origins::Custom)
	{
		origin = Utils::SetOrigin(body, originPreset);
	}
}

void Zombie::SetOrigin(const sf::Vector2f& newOrigin)
{
	originPreset = Origins::Custom;
	origin = newOrigin;
	body.setOrigin(origin);
}

sf::FloatRect Zombie::GetLocalBounds()
{
	return body.getLocalBounds();
}

sf::FloatRect Zombie::GetGlobalBounds()
{
	return body.getGlobalBounds();
}

void Zombie::Init()
{
	sortingLayer = SortingLayers::Foreground;
	sortingOrder = 0;
	SetType(types);
}

void Zombie::Release()
{
}

void Zombie::Reset()
{
	sceneGame = (SceneGame*)(SCENE_MGR.GetCurrentScene());
	player = dynamic_cast<Player*>(SCENE_MGR.GetCurrentScene()->FindGo("Player"));

	body.setTexture(TEXTURE_MGR.Get(textureId));
	SetOrigin(Origins::MC);
	SetPosition({ 0.f,0.f });
	SetRotation(0.f);
	SetScale({ 1.f,1.f });
}

void Zombie::Update(float dt)
{
	attackTimer += dt;
	actionRecoveryTimer += dt;
	if (actionRecoveryTimer > actionRecoveryTime)
	{
		if (player != nullptr && Utils::Distance(position, player->GetPosition()))
		{
			direction = Utils::GetNormal(player->GetPosition() - position);
			body.setRotation(Utils::Angle(direction));
			SetPosition(position + direction * speed * dt);
		}
	}

	if (hp <= 0)
		SetActive(false);

	debugBox.SetVisible((SceneGame*)(SCENE_MGR.GetCurrentScene())->GetDebugMode());
	if (debugBox.IsVisible())
	{
		debugBox.SetBounds(GetGlobalBounds());
		if (debugHitTimer > 0.f)
		{
			debugHitTimer -= dt;
			debugBox.SetDebugBoxColor(sf::Color::Red);
		}
		else
			debugBox.SetDebugBoxColor(sf::Color::Green);
	}
}

void Zombie::Draw(sf::RenderWindow& window)
{
	window.draw(body);
	if (debugBox.IsVisible())
		debugBox.Draw(window);
}

void Zombie::SetType(Types type)
{
	this->types = type;
	switch (this->types)
	{
	case Types::Bloater:
		textureId = "graphics/bloater.png";
		maxHp = 50;
		hp = maxHp;
		attackInterval = 4.f;
		damage = 10;
		speed = 75.f;
		actionRecoveryTime = 3.f;
		break;
	case Types::Chaser:
		textureId = "graphics/chaser.png";
		maxHp = 20;
		hp = maxHp;
		attackInterval = 2.f;
		damage = 2;
		speed = 100.f;
		actionRecoveryTime = 1.f;

		break;
	case Types::Crawler:
		textureId = "graphics/crawler.png";
		maxHp = 30;
		hp = maxHp;
		attackInterval = 3.f;
		damage = 5;
		speed = 40.f;
		actionRecoveryTime = 2.f;

		break;
	}
	body.setTexture(TEXTURE_MGR.Get(textureId), true); // true �ֳִ´ٰ�?
}

int Zombie::Attack()
{
	if (attackTimer < attackInterval)
		return 0;
	attackTimer = 0;
	actionRecoveryTimer = 0;
	return damage;
}

void Zombie::TurnDebugBox(bool active, sf::Color color)
{
	debugBox.SetVisible(active);
	if (active)
	{
		debugBox.SetBounds(this->GetGlobalBounds());
		debugBox.SetDebugBoxColor(color);
	}
}

int Zombie::GetZombieHp()
{
	return hp;
}

void Zombie::OnDamage(int dmg_in)
{
	hp -= dmg_in;
	debugHitTimer = 0.15f;
	if (hp <= 0 && sceneGame!=nullptr)
	{
		sceneGame->OnZombieDie(this);
	}
}
