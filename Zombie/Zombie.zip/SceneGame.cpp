#include "stdafx.h"
#include "SceneGame.h"
#include "Player.h"
#include "Bullet.h"
#include "Zombie.h"
#include "Item.h"
#include "TileMap.h"
#include "DebugBox.h"
#include "UserInterface.h"

SceneGame::SceneGame()
	:Scene(SceneIds::Game)
{
}

void SceneGame::Init()
{
	player = AddGo(new Player("graphics/player.png", "Player"));
	tileMap = AddGo(new TileMap());
	ui = AddGo(new UserInterface());
	ui->SetPlayer(player);
	

	Scene::Init();
}

void SceneGame::Release()
{
	Scene::Release();
}

void SceneGame::Enter()
{
	worldView.setCenter(0.f, 0.f);

	FONT_MGR.Load("fonts/DS-DIGI.ttf");

	Scene::Enter();
}

void SceneGame::Exit()
{
	for (auto zombie : zombies)
	{
		RemoveGo(zombie);
		zombiePool.Return(zombie);
	}
	zombies.clear();

	for (auto bullet : bullets)
	{
		RemoveGo(bullet);
		bulletPool.Return(bullet);
	}
	bullets.clear();

	for (auto item : items)
	{
		RemoveGo(item);
		itemPool.Return(item);
	}
	items.clear();

	FONT_MGR.Unload("fonts/DS-DIGI.ttf");

	Scene::Exit();
}

void SceneGame::Update(float dt)
{
	/*worldView.setSize(FRAMEWORK.GetWindowSizeF());*/

	itemSpawnTimer += dt;
	zombieSpawnTimer += dt;

	Scene::Update(dt);

	if (InputMgr::GetKeyDown(sf::Keyboard::Grave))
	{
		SCENE_MGR.ChangeScene(SceneIds::Game);
	}

	if (InputMgr::GetKeyDown(sf::Keyboard::Num1))
	{
		SpawnZombies(10);
	}
	if (InputMgr::GetKeyDown(sf::Keyboard::Num2))
	{
		SpawnItem(1);
	}
	if (InputMgr::GetKeyDown(sf::Keyboard::Num9))
	{
		this->TurnDebugBox(true);
	}
	if (InputMgr::GetKeyDown(sf::Keyboard::Num0))
	{
		this->TurnDebugBox(false);
	}

	if (zombieSpawnTimer > zombieSpawnDuration)
	{
		zombieSpawnTimer -= zombieSpawnDuration;
		SpawnZombies(5);
	}
	if (itemSpawnTimer > itemSpawnDuration)
	{
		itemSpawnTimer -= itemSpawnDuration;
		SpawnItem(1);
	}

	if (player != nullptr)
	{
		worldView.setCenter(player->GetPosition());
	}
}

void SceneGame::Draw(sf::RenderWindow& window)
{
	Scene::Draw(window);
}

//void SceneGame::CollisionCheck()
//{
//	for (auto zombie : zombies)
//	{
//		if (!zombie->IsActive())
//			continue;
//		
//		// CB == collision box , pPos == player position
//		sf::FloatRect CB = zombie->GetGlobalBounds();
//		sf::Vector2f pPos = player->GetPosition();
//		if (pPos.x > CB.left && pPos.x < CB.left + CB.width &&
//			pPos.y > CB.top && pPos.y < CB.top + CB.height)
//		{
//			player->ReducePlayerHp(zombie->Attack());
//		}
//		
//		for (auto bullet : bullets)
//		{
//			if (!bullet->IsActive())
//				continue;
//			
//			// bPos == bullet position
//			sf::Vector2f bPos = bullet->GetPosition();
//			if (bPos.x > CB.left && bPos.x < CB.left + CB.width &&
//				bPos.y > CB.top && bPos.y < CB.top + CB.height)
//			{
//				zombie->ReduceZombieHp(bullet->GetBulletDmg());
//				bullet->SetActive(false);
//			}	
//		}
//	}
//}

void SceneGame::SpawnZombies(int count)
{
	for (int i = 0; i < count; i++)
	{
		Zombie* zombie = zombiePool.Take();
		zombies.push_back(zombie);

		Zombie::Types zombieType = (Zombie::Types)Utils::RandomRange(0, Zombie::TotalTypes -1);
		zombie->SetType(zombieType);

		sf::Vector2f pos;
		pos.x = Utils::RandomRange(tileMap->GetGlobalBounds().left, 
			tileMap->GetGlobalBounds().left +tileMap->GetGlobalBounds().width);
		pos.y = Utils::RandomRange(tileMap->GetGlobalBounds().top, 
			tileMap->GetGlobalBounds().top + tileMap->GetGlobalBounds().height);
		zombie->SetPosition(pos);

		AddGo(zombie);
	}
}

void SceneGame::SpawnItem(int count)
{
	for (int i = 0; i < count; i++)
	{
		Item* item = itemPool.Take();
		items.push_back(item);

		Item::ItemTypes itemType = (Item::ItemTypes)Utils::RandomRange(0, Item::TotalItemTypes -1);
		item->SetType(itemType);

		sf::Vector2f pos;
		pos.x = Utils::RandomRange(tileMap->GetGlobalBounds().left,
			tileMap->GetGlobalBounds().left + tileMap->GetGlobalBounds().width);
		pos.y = Utils::RandomRange(tileMap->GetGlobalBounds().top,
			tileMap->GetGlobalBounds().top + tileMap->GetGlobalBounds().height);
		item->SetPosition(pos);

		AddGo(item);
	}
}

Bullet* SceneGame::TakeBullet()
{
	Bullet* bullet = bulletPool.Take();
	bullets.push_back(bullet);
	AddGo(bullet);
	return bullet;
}

void SceneGame::ReturnBullet(Bullet* bullet)
{
	RemoveGo(bullet);
	bulletPool.Return(bullet);
	bullets.remove(bullet);
}

void SceneGame::OnZombieDie(Zombie* zombie)
{
	RemoveGo(zombie);
	zombiePool.Return(zombie);
	zombies.remove(zombie);
}

void SceneGame::OnBulletHit(Bullet* bullet)
{
	RemoveGo(bullet);
	bulletPool.Return(bullet);
	bullets.remove(bullet);
}

void SceneGame::OnItemPickedUp(Item* item)
{
	RemoveGo(item);
	itemPool.Return(item);
	items.remove(item);
}
